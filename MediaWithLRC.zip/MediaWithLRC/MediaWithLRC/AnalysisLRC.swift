//
//  AnalysisLRC.swift
//  MediaWithLRC
//
//  Created by 江若铭 on 16/7/29.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class AnalysisLRC {
    var lrcPath:String! = nil
    var lrc:String! = nil
    
    var musicTimeSeconds = [Double]()
    var musicTimeMinutes = [Int]()
    var lyrics = [String]()
    
    init(path:String){
        self.lrcPath = path
        if !lrcPath.isEmpty {
            let data = NSData(contentsOfFile: lrcPath)
            lrc = NSString(data: data!, encoding: NSUTF8StringEncoding) as! String
        }
    }
    
    func analysisLRC(){
        let arr = lrc.componentsSeparatedByString("\n")
        var temp = ""
        
        for i in arr {
            //获取时间
            let rangeT = Range<String.Index>(start: (i.rangeOfString("[")?.endIndex)!, end: (i.rangeOfString("]")?.startIndex)!)
            let time = i.substringWithRange(rangeT)
            //获取分秒
            let rangeTS = Range<String.Index>(start: (time.rangeOfString(".")?.endIndex)!, end: time.endIndex)
            let tSeconds = (i.substringWithRange(rangeTS) as NSString).doubleValue
            
            
            //获取秒
            let rangeS = Range<String.Index>(start: (i.rangeOfString(":")?.endIndex)!, end: (i.rangeOfString(".")?.startIndex)!)
            let seconds = (i.substringWithRange(rangeS) as NSString).doubleValue
            
            
            //获取分
            let rangeM = Range<String.Index>(start: (i.rangeOfString("[")?.endIndex)!, end: (i.rangeOfString(":")?.startIndex)!)
            let minutes = (i.substringWithRange(rangeM) as NSString).integerValue
            
            
            musicTimeMinutes.append(minutes)
            musicTimeSeconds.append(tSeconds+seconds)
            let lyric = i.substringFromIndex((i.rangeOfString("]")?.endIndex)!)
            if lyric.isEmpty {
                lyrics.append(temp)
            }else{
                lyrics.append(lyric)
                temp = lyric
            }
        }
        
        
    }
    
    func getMusicTimeMinutes() -> Array<Int> {
        return musicTimeMinutes
    }
    
    func getMusicTimeSeconds() -> Array<Double> {
        return musicTimeSeconds
    }
    
    func getLyrics() -> Array<String> {
        return lyrics
    }
    
}
