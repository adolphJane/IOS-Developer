//
//  ViewController.swift
//  MediaWithLRC
//
//  Created by 江若铭 on 16/7/29.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit
import AVFoundation

class ViewController: UIViewController {

    var player:AVAudioPlayer!
    var timer:NSTimer!
    var thread:NSThread!
    
    @IBOutlet weak var lyricText: UILabel!
    var lrcPath:String! = nil
    var analysis:AnalysisLRC!
    
    var musicTimeSeconds:Array<Double>!
    var musicTimeMinutes:Array<Int>!
    var lyrics:Array<String>!
    
    var currentRunloop:NSRunLoop!
    var m = 0
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        setInit()
        
        
        analysis = AnalysisLRC(path: lrcPath)
        analysis.analysisLRC()
    
        musicTimeSeconds = analysis.getMusicTimeSeconds()
        musicTimeMinutes = analysis.getMusicTimeMinutes()
        lyrics = analysis.getLyrics()
        
        
    }

    func StartTimer() {
        timer = NSTimer(timeInterval: 0.1, target: self, selector: #selector(self.onUpdate), userInfo: nil, repeats: true)
        currentRunloop = NSRunLoop.currentRunLoop()
        currentRunloop.addTimer(timer, forMode: NSDefaultRunLoopMode)
        currentRunloop.run()
    }
    
    func setInit() {
        do{
            try player = AVAudioPlayer(contentsOfURL: NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("mic/sound", ofType: "mp3")!))
        }catch{
            
        }
        lrcPath = NSBundle.mainBundle().pathForResource("mic/lyric", ofType: "lrc")
        musicTimeMinutes = Array()
        musicTimeSeconds = Array()
        lyrics = Array()
        
        
    }
    
    func onUpdate(){
        
        let c = player.currentTime
        var str = NSString(format: "%.1f", c).doubleValue
        if musicTimeMinutes[m] == Int(str / 60) {
            str = NSString(format: "%.1f", str % 60).doubleValue
            if musicTimeSeconds[m] == str {
                dispatch_async(dispatch_get_main_queue(), {
                    self.lyricText.text = self.lyrics[self.m]
                    self.m += 1
                })
            }
        }
    }

    @IBAction func stopAction(sender: AnyObject) {
        player.stop()
        player.currentTime = 0
        timer.invalidate()
        timer = nil
        m = 0
    }
    @IBAction func pauseAction(sender: AnyObject) {
        player.pause()
        timer.invalidate()
    }
    @IBAction func playAction(sender: AnyObject) {
        thread = NSThread(target: self, selector: #selector(self.StartTimer), object: nil)
        thread.start()

        player.play()
    }
    
    override func observeValueForKeyPath(keyPath: String?, ofObject object: AnyObject?, change: [String : AnyObject]?, context: UnsafeMutablePointer<Void>) {
        
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

