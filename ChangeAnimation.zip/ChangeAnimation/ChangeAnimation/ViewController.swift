//
//  ViewController.swift
//  ChangeAnimation
//
//  Created by 江若铭 on 16/7/26.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var redView: UIView!
    @IBOutlet weak var greenView: UIView!
    @IBOutlet weak var blueView: UIView!
    @IBOutlet weak var orangeView: UIView!
    
    var timer:NSTimer!
    var flag = true
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        
        self.view.multipleTouchEnabled = true
    }
    
    func startAnimation(colorView:UIView) {
        UIView.beginAnimations("", context: nil)
        UIView.setAnimationCurve(.EaseInOut)
        UIView.setAnimationDuration(1)
        switch arc4random() % 4 {
        case 0:
            UIView.setAnimationTransition(.CurlDown, forView: colorView, cache: true)
        case 1:
            UIView.setAnimationTransition(.CurlUp, forView: colorView, cache: true)
        case 2:
            UIView.setAnimationTransition(.FlipFromLeft, forView: colorView, cache: true)
        case 3:
            UIView.setAnimationTransition(.FlipFromRight, forView: colorView, cache: true)
        default:
            UIView.setAnimationTransition(.None, forView: colorView, cache: true)
        }
        UIView.commitAnimations()
    }
    
    func antimationSet() {
        self.startAnimation(self.redView)
        self.startAnimation(self.blueView)
        self.startAnimation(self.greenView)
        self.startAnimation(self.orangeView)
    }
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        for touch:AnyObject in touches {
            let t:UITouch = touch as! UITouch
            if t.tapCount == 1 {
                if flag {
                    timer = NSTimer.scheduledTimerWithTimeInterval(1, target: self, selector: #selector(self.antimationSet), userInfo: nil, repeats: true)
                    timer.fire()
                    flag = false
                }else{
                    timer.invalidate()
                    flag = true
                }
            }
            
        }
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

