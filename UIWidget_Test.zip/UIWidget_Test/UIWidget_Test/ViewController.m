//
//  ViewController.m
//  UIWidget_Test
//
//  Created by 江若铭 on 16/5/15.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (weak, nonatomic) IBOutlet UISlider *slideButton;
@property (weak, nonatomic) IBOutlet UISwitch *switchButton;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    UIImageView *image = [[UIImageView alloc]initWithFrame:CGRectMake(50, 280, 200, 200)];
    [image setImage:[UIImage imageNamed:@"2.png"]];
    image.backgroundColor =[UIColor redColor];
    
    [self.view addSubview:image];
    
    [self.slideButton addTarget:self action:@selector(slideAlpha) forControlEvents:UIControlEventValueChanged];
    [self.switchButton addTarget:self action:@selector(switchTheFunction) forControlEvents:UIControlEventTouchUpInside];
}

-(void)slideAlpha{
    self.imageView.alpha = (self.slideButton.value - 1) / 100;
}

-(void)switchTheFunction{
    if(self.switchButton.isOn){
        self.slideButton.enabled = YES;
    }else{
        self.slideButton.enabled = NO;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
