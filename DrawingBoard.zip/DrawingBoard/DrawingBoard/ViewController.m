//
//  ViewController.m
//  DrawingBoard
//
//  Created by 江若铭 on 16/5/29.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import "ViewController.h"

#import "LineModel.h"
#import "DrawView.h"


@interface ViewController ()

@property (weak, nonatomic) IBOutlet UIImageView *imageView;
@property (nonatomic, strong) NSMutableArray *linePoints;
@property (nonatomic, strong) LineModel *currentLineModel;
@property (nonatomic, strong) DrawView *drawView;

@property (nonatomic,assign) CGFloat lineWidth;
@property (nonatomic,assign) CGPoint touchPoint;

@property (weak, nonatomic) IBOutlet UISlider *sliderButton;
@property (weak, nonatomic) IBOutlet UIButton *saveButton;
@property (weak, nonatomic) IBOutlet UIButton *clearButton;
@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self initWidget];
}

- (void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    CGPoint touchPoint;
    
    UITouch *touch = [touches anyObject];
    
    self.lineWidth = self.sliderButton.value;
    
    if (touch) {
        
        touchPoint = [touch locationInView:self.imageView];
        
        NSLog(@"touchesBegan : %f, %f\n", touchPoint.x, touchPoint.y);
        
        self.currentLineModel = [[LineModel alloc] init];
        
        self.currentLineModel.startPoint = touchPoint;
        
        [self.linePoints addObject:_currentLineModel];
        
    }
}

- (void)touchesMoved:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
    UITouch *touch = [touches anyObject];
    
    
    if (touch) {
        
        self.touchPoint = [touch locationInView:self.imageView];
        
        [self.currentLineModel.linePoints addObject:[NSValue valueWithCGPoint:self.touchPoint]];
        
        self.imageView.image = [self drawLineWithStroke:self.lineWidth startPoint:self.currentLineModel.startPoint endPoint:self.touchPoint];
        
    }
}

- (void)touchesEnded:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event
{
    
}

-(void)initWidget{
    [self.sliderButton addTarget:self action:@selector(setLineWidth) forControlEvents:UIControlEventValueChanged];
    [self.saveButton addTarget:self action:@selector(saveBoard) forControlEvents:UIControlEventTouchUpInside];
    [self.clearButton addTarget:self action:@selector(clearBoard) forControlEvents:UIControlEventTouchUpInside];
}

-(void)setLineWidth{
    self.lineWidth = self.sliderButton.value;
    self.imageView.image = [self drawLineWithStroke:self.lineWidth startPoint:self.currentLineModel.startPoint endPoint:self.touchPoint];
}

-(void)saveBoard{
    UIImageWriteToSavedPhotosAlbum(self.imageView.image,self, @selector(image:didFinishSavingWithError:contextInfo:), nil);
}

- (void)image:(UIImage *)image didFinishSavingWithError:(NSError *)error contextInfo:(void *)contextInfo{
    NSString *msg = nil ;
    if(error != NULL){
        msg = @"保存图片失败" ;
    }else{
        msg = @"保存图片成功" ;
    }
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"保存图片结果提示"
                                                    message:msg
                                                   delegate:self
                                          cancelButtonTitle:@"确定"
                                          otherButtonTitles:nil];
    [alert show];
}

-(void)clearBoard{
    UIImage *image = nil;
    self.imageView.image = image;
    
    [self.linePoints removeAllObjects];
    
}

- (UIImage *)drawLineWithStroke:(CGFloat)width startPoint:(CGPoint)startPoint endPoint:(CGPoint)endPoint
{
    
    UIImage *image = nil;
    
    UIGraphicsBeginImageContext(self.imageView.frame.size);
    
    CGContextRef context = UIGraphicsGetCurrentContext();
    
    CGContextSetLineWidth(context, width);
    CGContextSetStrokeColorWithColor(context, [UIColor redColor].CGColor);
    
    
    
    ///// 需要绘制 linePoints 所有数据
    
    for (LineModel *model in self.linePoints)
    {
        CGContextMoveToPoint(context, model.startPoint.x, model.startPoint.y);
        
        for (NSValue *value in model.linePoints)
        {
            CGPoint point = [value CGPointValue];
            
            CGContextAddLineToPoint(context, point.x, point.y);
            
        }
        
    }
    
    CGContextStrokePath(context);
    
    image = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    
    return image;
}

#pragma mark - setters and getters

- (NSMutableArray *)linePoints
{
    if (!_linePoints) {
        _linePoints = [[NSMutableArray alloc] init];
    }
    
    return _linePoints;
}

- (DrawView *)drawView
{
    if (!_drawView) {
        _drawView = [[DrawView alloc] initWithFrame:self.view.bounds];
    }
    
    return _drawView;
}

@end
