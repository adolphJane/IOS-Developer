//
//  ContentView.swift
//  Notes
//
//  Created by 江若铭 on 16/8/18.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class ContentView: UITextView,UITextViewDelegate {

    var placeholderLabel:UILabel!
    
    
    func initTextView() {
        self.placeholderLabel = UILabel.init()
        self.placeholderLabel.frame = CGRectMake(5 , 5, 200, 20)
        self.placeholderLabel.font = UIFont.systemFontOfSize(15)
        self.placeholderLabel.text = "Please write something....."
        self.addSubview(self.placeholderLabel)
        self.placeholderLabel.textColor = UIColor.init(colorLiteralRed: 72/256, green: 82/256, blue: 93/256, alpha: 1)
    }
   
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        self.placeholderLabel.hidden = true
        return true
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        if textView.text.isEmpty {
            self.placeholderLabel.hidden = false
        }
        else{
            self.placeholderLabel.hidden = true
        }
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if text == "\n"{
            textView.resignFirstResponder()
        }
        return true
    }

}
