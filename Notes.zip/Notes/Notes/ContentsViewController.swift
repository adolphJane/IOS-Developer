//
//  ContentsViewController.swift
//  Notes
//
//  Created by 江若铭 on 16/8/18.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit
import CoreData

class ContentsViewController: UIViewController,UITextViewDelegate {

    
    @IBOutlet weak var titleView: UITextField!
    
    var data:NSManagedObject!
    var context:NSManagedObjectContext!
    var isNew:Bool = true
    var content:UITextView!
    var placeholderLabel:UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        initTextView()
        // Do any additional setup after loading the view.
        if isNew {
            titleView.placeholder = "Title"
            self.placeholderLabel.text = "Please write something....."
        }else{
            titleView.text = data.valueForKey("title") as? String
            content.text = data.valueForKey("content") as! String
        }
        
    }

    func initTextView() {
        content = UITextView(frame: CGRectMake(0, 70, self.view.frame.width, 350))
        self.view.addSubview(content)
        content.font = UIFont.systemFontOfSize(15)
        content.delegate = self
        
        self.placeholderLabel = UILabel.init()
        self.placeholderLabel.frame = CGRectMake(5 , 5, 200, 20)
        self.placeholderLabel.font = UIFont.systemFontOfSize(15)
        self.placeholderLabel.text = "Please write something....."
        self.content.addSubview(self.placeholderLabel)
        self.placeholderLabel.textColor = UIColor.init(colorLiteralRed: 72/256, green: 82/256, blue: 93/256, alpha: 1)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //保存-按钮事件
    @IBAction func saveAction(sender: AnyObject) {
       
        if isNew {
            context = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
            let row:AnyObject = NSEntityDescription.insertNewObjectForEntityForName("Note", inManagedObjectContext: context)
            row.setValue(content.text, forKey: "content")
            row.setValue(titleView.text, forKey: "title")
            do{
                try context.save()
            }catch{
                
            }
        }else{
            data.setValue(content.text, forKey: "content")
            data.setValue(titleView.text, forKey: "title")
            do{
                try data.managedObjectContext?.save()
            }catch{
                
            }
        }
        dismissViewControllerAnimated(true, completion: nil)
    }
    //取消-按钮事件
    @IBAction func cancleAction(sender: AnyObject) {
        dismissViewControllerAnimated(true, completion: nil)
    }
    
    //TextView的方法
    override func touchesEnded(touches: Set<UITouch>, withEvent event: UIEvent?) {
        self.content.resignFirstResponder()
        self.titleView.resignFirstResponder()
    }
    
    func textViewShouldBeginEditing(textView: UITextView) -> Bool {
        self.placeholderLabel.hidden = true
        return true
    }
    
    func textViewDidEndEditing(textView: UITextView) {
        if textView.text.isEmpty {
            self.placeholderLabel.hidden = false
        }
        else{
            self.placeholderLabel.hidden = true
        }
    }
    
    func textView(textView: UITextView, shouldChangeTextInRange range: NSRange, replacementText text: String) -> Bool {
        if text == "\n"{
            textView.resignFirstResponder()
        }
        return true
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
