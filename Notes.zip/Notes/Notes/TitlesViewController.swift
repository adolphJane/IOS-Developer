//
//  TitlesViewController.swift
//  Notes
//
//  Created by 江若铭 on 16/8/18.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit
import CoreData

class TitlesViewController: UITableViewController {

    var context:NSManagedObjectContext!
    var dataArr:Array<AnyObject> = []
    var data:NSManagedObject!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        context = (UIApplication.sharedApplication().delegate as! AppDelegate).managedObjectContext
        
        
        // Uncomment the following line to preserve selection between presentations
        // self.clearsSelectionOnViewWillAppear = false

        // Uncomment the following line to display an Edit button in the navigation bar for this view controller.
        // self.navigationItem.rightBarButtonItem = self.editButtonItem()
        
        
        //加载导航栏的编辑和添加按钮
        self.navigationItem.leftBarButtonItem = self.editButtonItem()
        let addButton = UIBarButtonItem(barButtonSystemItem: .Add, target: self, action: #selector(self.insertNewObject))
        self.navigationItem.rightBarButtonItem = addButton
        //刷新数据
        self.refreshData()
    }
    //添加按钮事件
    func insertNewObject() {
        let vc = storyboard?.instantiateViewControllerWithIdentifier("ContentView") as! ContentsViewController
        vc.isNew = true
        presentViewController(vc, animated: true, completion: nil)
        
    }
    
    //从数据库中读取数据并刷新数据
    func refreshData() {
        let f = NSFetchRequest(entityName: "Note")
        do{
            try dataArr = context.executeFetchRequest(f)
            dataArr = dataArr.reverse()
        }catch{
            
        }
        self.tableView.reloadData()
    }
    //显示触发事件
    override func viewWillAppear(animated: Bool) {
        self.refreshData()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    // MARK: - Table view data source

    override func numberOfSectionsInTableView(tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }

    override func tableView(tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        // #warning Incomplete implementation, return the number of rows
        return dataArr.count
    }

    //cell自定义显示
    override func tableView(tableView: UITableView, cellForRowAtIndexPath indexPath: NSIndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCellWithIdentifier("cell", forIndexPath: indexPath) as UITableViewCell

        // Configure the cell...

        let label = cell.viewWithTag(2) as! UILabel
        label.text = dataArr[indexPath.row].valueForKey("title") as? String
        
        return cell
    }
    

    
    // Override to support conditional editing of the table view.
    override func tableView(tableView: UITableView, canEditRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    //跳转到所选cell对应的记事本view事件
    override func tableView(tableView: UITableView, didSelectRowAtIndexPath indexPath: NSIndexPath) {
        data = dataArr[indexPath.row] as! NSManagedObject
        let vc = storyboard?.instantiateViewControllerWithIdentifier("ContentView") as! ContentsViewController
        vc.data = data
        vc.isNew = false
        presentViewController(vc, animated: true, completion: nil)
    }
    
    // Override to support editing the table view.
    override func tableView(tableView: UITableView, commitEditingStyle editingStyle: UITableViewCellEditingStyle, forRowAtIndexPath indexPath: NSIndexPath) {
        if editingStyle == .Delete {
            // Delete the row from the data source
            context.deleteObject(dataArr[indexPath.row] as! NSManagedObject)
            do{
                try context.save()
            }catch{
                
            }
            self.refreshData()
        } else if editingStyle == .Insert {
            // Create a new instance of the appropriate class, insert it into the array, and add a new row to the table view
        }    
    }
    

    /*
    // Override to support rearranging the table view.
    override func tableView(tableView: UITableView, moveRowAtIndexPath fromIndexPath: NSIndexPath, toIndexPath: NSIndexPath) {

    }
    */

    /*
    // Override to support conditional rearranging of the table view.
    override func tableView(tableView: UITableView, canMoveRowAtIndexPath indexPath: NSIndexPath) -> Bool {
        // Return false if you do not want the item to be re-orderable.
        return true
    }
    */

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
