//
//  Model.swift
//  Group-Buying
//
//  Created by 江若铭 on 16/5/21.
//  Copyright © 2016年 Adolph. All rights reserved.
//

import UIKit

class Model: NSObject {
    override func setValue(value: AnyObject?, forUndefinedKey key: String){
        return;
    }
    
    var name:String = ""
    
    var price:String = ""
    
    var pic:String = ""
    
    var amount:String = ""
    
    var modelArr:NSMutableArray = []
    
    func layoutView() -> NSMutableArray {
        let strPath = NSBundle.mainBundle().URLForResource("goodsList", withExtension: "plist")
    
        let dataArray = NSArray(contentsOfURL: strPath!)
        
        for dic in dataArray!{
            // 创建对象
            let model = Model()
            // 将快速枚举值进行类型转换
            let dica:Dictionary<String,AnyObject> = dic as! Dictionary
            
            // 数据转模型
            model.setValuesForKeysWithDictionary(dica)
            
            // 添加入数组中
            modelArr.addObject(model)
        }
        
        return modelArr
    }
    
}
