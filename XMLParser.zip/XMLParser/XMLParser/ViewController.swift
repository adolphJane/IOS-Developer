//
//  ViewController.swift
//  XMLParser
//
//  Created by 江若铭 on 16/8/16.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class ViewController: UIViewController,NSXMLParserDelegate {

    var dict:[Dictionary<String,String>]!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let xml = XMLParse()
        xml.initXML()
        dict = xml.getDict()
        
        print(dict)
    }
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

