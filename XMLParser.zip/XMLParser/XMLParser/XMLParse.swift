//
//  XMLParse.swift
//  XMLParser
//
//  Created by 江若铭 on 16/8/16.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class XMLParse: NSObject,NSXMLParserDelegate {
    
    var dict:[Dictionary<String,String>]!
    var currentDict:Dictionary<String,String>!
    var currentNode:String!
    
    func initXML() {
        currentDict = Dictionary<String,String>()
        dict = [Dictionary<String,String>]()
        let parser = NSXMLParser(contentsOfURL: NSURL(fileURLWithPath: NSBundle.mainBundle().pathForResource("data", ofType: "xml")!))
        parser?.delegate = self
        parser?.parse()
        
    }
    
    func parser(parser: NSXMLParser, didStartElement elementName: String, namespaceURI: String?, qualifiedName qName: String?, attributes attributeDict: [String : String]) {
        currentNode = elementName
        if elementName == "student" {
            if let id = attributeDict["id"] {
                currentDict["id"] = id
            }
        }
       
    }
    
    func parser(parser: NSXMLParser, foundCharacters string: String) {
        let str = string.stringByTrimmingCharactersInSet(NSCharacterSet.whitespaceAndNewlineCharacterSet())
        if str != "" {
            currentDict[currentNode] = str
        }
       
    }
    
    func parser(parser: NSXMLParser, didEndElement elementName: String, namespaceURI: String?, qualifiedName qName: String?) {
        if elementName == "age" {
            dict.append(currentDict)
            currentDict.removeAll()
        }
        
    }
    
    func getDict() -> [Dictionary<String,String>] {
        return dict
    }
}
