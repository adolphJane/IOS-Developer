//
//  CircleLoaderView.swift
//  IOSAppDownload
//
//  Created by 江若铭 on 16/7/19.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class CircleLoaderView: UIView {
    
    let startAngle = M_PI * 3 / 2
    var endAngle = M_PI * 3 / 2
    
    
    
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        let color = UIColor.redColor()
        color.set()
        
        let bPath = UIBezierPath.init(arcCenter: CGPointMake(100.0, 100.0), radius: 70.0, startAngle: CGFloat (startAngle), endAngle: CGFloat(endAngle), clockwise: true)
        bPath.addLineToPoint(CGPointMake(100.0, 100.0))
        bPath.lineWidth = 5.0
        bPath.fillWithBlendMode(CGBlendMode.Normal, alpha: 0.5)
        
        endAngle += M_PI / 20
    }
 

}
