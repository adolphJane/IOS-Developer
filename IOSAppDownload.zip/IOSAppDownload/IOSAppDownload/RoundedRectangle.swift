//
//  RoundedRectangle.swift
//  IOSAppDownload
//
//  Created by 江若铭 on 16/7/19.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class RoundedRectangle: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        self.backgroundColor = UIColor.clearColor()
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
        let pathRect = CGRectInset(self.bounds, 1, 1)
        let path = UIBezierPath(roundedRect: pathRect, cornerRadius: 20)
        path.lineWidth = 3
        UIColor.grayColor().setFill()
        path.fill()
        path.stroke()
    }
 

}
