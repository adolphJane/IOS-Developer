//
//  Circle.swift
//  IOSAppDownload
//
//  Created by 江若铭 on 16/7/19.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class Circle: UIView {

    
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
        
        let color = UIColor.whiteColor()
        color.set()
        
        let bPath = UIBezierPath.init(ovalInRect: CGRectMake(25, 25, 150, 150))
        bPath.lineWidth = 5.0
        bPath.fill()

    }
    

}
