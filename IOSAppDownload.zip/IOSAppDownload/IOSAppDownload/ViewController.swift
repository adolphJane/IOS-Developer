//
//  ViewController.swift
//  IOSAppDownload
//
//  Created by 江若铭 on 16/7/19.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var timer:NSTimer!
    let progress = CircleLoaderView(frame: CGRectMake(0, 0, 200, 200))
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let rect = RoundedRectangle(frame: CGRectMake(100, 100, 200, 200))
        self.view.addSubview(rect)
        
        let circle = Circle(frame: CGRectMake(0, 0, 200, 200))
        circle.backgroundColor = UIColor.clearColor()
        rect.addSubview(circle)
        
        progress.backgroundColor = UIColor.clearColor()
        circle.addSubview(progress)
        
        timer = NSTimer.scheduledTimerWithTimeInterval(0.1, target: self, selector: #selector(self.ReDraw), userInfo: nil, repeats: true)
        
    }
    
    func ReDraw() {
        progress.setNeedsDisplay()
        if progress.endAngle > progress.startAngle+M_PI*2 {
            timer.invalidate() // 停止计时器
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

