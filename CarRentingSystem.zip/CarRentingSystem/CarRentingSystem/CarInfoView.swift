//
//  CarInfoView.swift
//  CarRentingSystem
//
//  Created by 江若铭 on 16/8/13.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class CarInfoView: UIView {

    @IBOutlet weak var carName: UILabel!
    @IBOutlet weak var carPrice: UILabel!
    @IBOutlet weak var carImage: UIImageView!
    @IBOutlet weak var carDistance: UILabel!
    
    func setModel(model:Car) {
        print(11111)
        print(model.name)
        let name = model.name as String
        carName.text = name
        print(22222)
        print(carName.text)
        carPrice.text = "\(model.price)元/辆"
        carDistance.text = "\(model.distance)千米"
        carImage.image = UIImage(named: model.pic)
    }
    
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
}
