//
//  ViewController.swift
//  CarRentingSystem
//
//  Created by 江若铭 on 16/8/7.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit
import MapKit

struct Car {
    var longitude:Double!
    var latitude:Double!
    var distance:Double!
    var name:String!
    var price:Double!
    var pic:String!
    var tag:Int
    
    init(_ longitude:Double,_ latitude:Double,_ distance:Double,_ name:String,_ price:Double,_ pic:String,_ tag:Int){
        self.longitude = longitude
        self.latitude = latitude
        self.distance = distance
        self.name = name
        self.price = price
        self.pic = pic
        self.tag = tag
    }
}

class ViewController: UIViewController,MKMapViewDelegate{

    //UI控件
    var filter:SEFilterControl!
    var locationButton:UIButton!
    var zoomInButton:UIButton!
    var zoomOutButton:UIButton!
    var grid:UICollectionView!
    //地图
    lazy var mapView:MKMapView = {
        var rect = self.view.bounds
        let _mapView = MKMapView(frame: rect)
        _mapView.delegate = self
        self.view.addSubview(_mapView)
        
        return _mapView
    }()
    lazy var locationManager:CLLocationManager = {
        let _locationManager = CLLocationManager()
        return _locationManager
    }()
    
    
    
    //数据
    let array = ["日租","月租","长租","试驾"]
    var screenWidth:CGFloat!
    var screenHeight:CGFloat!
    var currentLocation:CLLocation!
    var distance:Double = 4000
    var selection = 1
    var isAppear = false
    var carView:CarInfoView!
    var carDay = [Car]()
    var carMonth = [Car]()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Do any additional setup after loading the view, typically from a nib.
        screenWidth = self.view.frame.width
        screenHeight = self.view.frame.height
        carView = CarInfoView()
        self.initMapView()
        self.initCarBoard()
        self.initCarModel()
        self.addAnnotation()
    }
    //MARK:- 初始化视图和数据
    func initMapView() {
        let status = CLLocationManager.authorizationStatus()
        if status == CLAuthorizationStatus.NotDetermined {
            self.locationManager.requestAlwaysAuthorization()
        }
        self.mapView.userTrackingMode = .Follow
        
        locationButton = UIButton(frame: CGRectMake(10, self.view.frame.size.height - 125, 45, 45))
        locationButton.setImage(UIImage(named: "pic/location"), forState: .Normal)
        locationButton.addTarget(self, action: #selector(self.locationAction), forControlEvents: .TouchUpInside)
        self.mapView.addSubview(locationButton)
        
        zoomInButton = UIButton(frame: CGRectMake(screenWidth - 55, self.view.frame.size.height - 171, 45, 45))
        zoomInButton.setImage(UIImage(named: "pic/zoomInButton"), forState: .Normal)
        zoomInButton.addTarget(self, action: #selector(self.zoomInAction), forControlEvents: .TouchUpInside)
        self.mapView.addSubview(zoomInButton)
        
        zoomOutButton = UIButton(frame: CGRectMake(screenWidth - 55, self.view.frame.size.height - 125, 45, 45))
        zoomOutButton.setImage(UIImage(named: "pic/zoomOutButton"), forState: .Normal)
        zoomOutButton.addTarget(self, action: #selector(self.zoomOutAction), forControlEvents: .TouchUpInside)
        self.mapView.addSubview(zoomOutButton)
        
        
    }
    //初始化汽车数据模型
    func initCarModel() {
        let strPath = NSBundle.mainBundle().pathForResource("CarInfo", ofType: "plist")
        let arry = NSArray(contentsOfFile: strPath!)
        let carDayL = arry![0] as! NSArray
        let carMonthL = arry![1] as! NSArray
        self.carDay.removeAll()
        self.carMonth.removeAll()
        self.carData(carDayL,type: 1)
        self.carData(carMonthL,type: 2)
        
    }
    
    func carData(carDict:NSArray,type:Int) {
        let carModel = CarModel()
        var num = 0
        
        print(carDict.count)
        for dict in carDict {
            carModel.setValuesForKeys(dict as! [String : String])
            if currentLocation == nil {
                currentLocation = CLLocation(latitude: 39, longitude: 116)
            }
            let locationLongitude = currentLocation.coordinate.longitude + (Double(arc4random() % 100) - 50) / 10000
            let locationLatitude = (Double(arc4random() % 100) - 50) / 10000 + currentLocation.coordinate.latitude
            let car = Car(locationLatitude, locationLongitude, carModel.distance.doubleValue, carModel.name, carModel.price.doubleValue, carModel.pic,num + 1)
            if type == 1 {
                carDay.append(car)
            }else if type == 2{
                carMonth.append(car)
            }
            num++
        }
    }

    func initCarBoard() {
        self.filter = SEFilterControl(frame: CGRectMake(0, self.view.frame.size.height - 70, self.view.frame.size.width, 20), titles: NSArray(array: array) as [AnyObject] )
        
        self.filter.addTarget(self, action: #selector(self.filterValueChanged(_:)), forControlEvents: .TouchUpInside)
        self.filter.progressColor = UIColor.groupTableViewBackgroundColor()
        self.filter.TopTitlesColor = UIColor.orangeColor()
        self.filter .setSelectedIndex(0)
        self.mapView.addSubview(filter)
    }
    
    //MARK:- 添加标记大头针
    func addAnnotation() {
        var annotations = [MKAnnotation]()
        if selection == 1 {
            self.mapView.removeAnnotations(mapView.annotations)
            for locate in carDay {
                let point = MKPointAnnotation()
                point.coordinate = CLLocationCoordinate2DMake(locate.longitude, locate.latitude)
                point.title = "\(locate.tag)"
                annotations.append(point)
            }
            print("day")
        }else if selection == 2 {
            self.mapView.removeAnnotations(mapView.annotations)
            for locate in carMonth {
                let point = MKPointAnnotation()
                point.coordinate = CLLocationCoordinate2DMake(locate.longitude, locate.latitude)
                point.title = "\(locate.tag)"
                annotations.append(point)
            }
            print("month")
        }
        
        self.mapView.addAnnotations(annotations)
    }
    //MARK:- 定位
    func mapView(mapView: MKMapView, didUpdateUserLocation userLocation: MKUserLocation) {
        currentLocation = userLocation.location
        self.mapView.setRegion(MKCoordinateRegionMakeWithDistance(self.currentLocation.coordinate, distance, distance), animated: true)
        self.initCarModel()
    }
  
    //MARK:-Car滑块值变化
    func filterValueChanged(sender:SEFilterControl) {
        if sender.SelectedIndex == 0 {
            selection = 1
            self.addAnnotation()
        }else if sender.SelectedIndex == 1{
            selection = 2
            self.addAnnotation()
        }
        NSLog("当前滑块位置%d",sender.SelectedIndex)
    }
    //MARK:-mapView
    func mapView(mapView: MKMapView, viewForAnnotation annotation: MKAnnotation) -> MKAnnotationView? {
        if annotation.isKindOfClass(MKUserLocation.self) {
            let view = MKPinAnnotationView()
            return view
        }
        let imageView = MKAnnotationView(annotation: annotation, reuseIdentifier: "pin")
        if selection == 1{
            imageView.image = UIImage(named: "pic/car.png")
        }else if selection == 2{
            imageView.image = UIImage(named: "pic/carMonth.png")
        }
        return imageView
    }
    //点击大头针事件
    func mapView(mapView: MKMapView, didSelectAnnotationView view: MKAnnotationView) {
        
        if isAppear {
            self.carView.removeFromSuperview()
            self.selecteCar(view)
        }else{
            self.selecteCar(view)
            isAppear = true
        }
    }
    //选择车信息
    func selecteCar(view:MKAnnotationView) {
        let title = ((view.annotation?.title)!)! as NSString
        if selection == 1 {
            useView(carDay[Int(title.intValue) - 1])
            
        }else if selection == 2{
            useView(carMonth[Int(title.intValue) - 1])
        }
    }
    //点击取消显示车信息的view
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        if self.mapView.subviews.contains(carView) {
            self.carView.removeFromSuperview()
            isAppear = false
        }
    }
    //加载车信息view
    func useView(model:Car) {
        carView = NSBundle.mainBundle().loadNibNamed("carView", owner: nil, options: nil).first as! CarInfoView
        carView.frame = CGRectMake(20,screenHeight - 150,screenWidth - 40,130)
        carView.setModel(model)
        self.mapView.addSubview(carView)
        
    }
    
    //MARK:-定位方法
    func locationAction() {
        print("location")
        self.mapView.setCenterCoordinate(self.currentLocation.coordinate, animated: true)
        self.mapView.setRegion(MKCoordinateRegionMakeWithDistance(self.currentLocation.coordinate, distance, distance), animated: true)
        self.initCarModel()
    }
    //MARK:-放大缩小
    func zoomInAction() {
        print("zoomIn")
        distance += 3000.0
        if distance >= 100000 {
            distance = 100000
        }
        self.mapView.setRegion(MKCoordinateRegionMakeWithDistance(self.currentLocation.coordinate, distance, distance), animated: true)
    }
    
    func zoomOutAction() {
        print("zoomOut")
        distance -= 3000.0
        if distance <= 1000 {
            distance = 1000
        }
        self.mapView.setRegion(MKCoordinateRegionMakeWithDistance(self.currentLocation.coordinate, distance, distance), animated: true)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}

