//
//  CarModel.swift
//  CarRentingSystem
//
//  Created by 江若铭 on 16/8/11.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import Foundation

class CarModel:NSObject {
    var name:String!
    var pic:String!
    var price:NSString!
    var distance:NSString!
    
    
    let keys = ["name","pic","price","distance"]
    
    func setValuesForKeys(keyedValues: [String : String]) {
        self.name = keyedValues[keys[0]]
        self.pic = keyedValues[keys[1]]
        self.price = keyedValues[keys[2]]
        self.distance = keyedValues[keys[3]]
    }
}
