//
//  main.m
//  DynamicArray
//
//  Created by 江若铭 on 16/5/5.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Array.h"
#include "Character.h"
#include "Integer.h"
#include "Object.h"

int main(int argc, const char * argv[]) {
    @autoreleasepool {
        Array *arr = ArrayCreate();
        
        ArrayAdd(arr, CharacterNew("小红"), *IntegerNew(22));
        ArrayAdd(arr, CharacterNew("小美"), *IntegerNew(12));
        ArrayAdd(arr, CharacterNew("小星"), *IntegerNew(18));
        ArrayAdd(arr, CharacterNew("小天"), *IntegerNew(16));
        ArrayAdd(arr, CharacterNew("小蓝"), *IntegerNew(15));

        
        
        for (int i = 0; i < ArrayGetLength(arr); i++) {
            printf("位置：%d\t名字:%s\t年龄:%d\n",i+1,ArrayGetName(arr, i),ArrayGetAge(arr, i));
        }
        
        ArrayRemoveAtIndex(arr, 0);
        printf("删除\n");
        for (int i = 0; i < ArrayGetLength(arr); i++) {
            printf("位置：%d\t名字:%s\t年龄:%d\n",i+1,ArrayGetName(arr, i),ArrayGetAge(arr, i));
        }
        
        Character *name6 = CharacterNew("小糯米");
        Integer *age6 = IntegerNew(15);
        ArrayAdd(arr, name6, *age6);
        printf("插入\n");
        for (int i = 0; i < ArrayGetLength(arr); i++) {
            printf("位置：%d\t名字:%s\t年龄:%d\n",i+1,ArrayGetName(arr, i),ArrayGetAge(arr, i));
        }
        
        printf("查找\n");
        ArrayFind(arr, 2);
      
        ArrayDestory(arr);
    }
    return 0;
}
