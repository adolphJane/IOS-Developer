//
//  Array.c
//  DynamicArray
//
//  Created by 江若铭 on 16/5/5.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#include "Array.h"
#include <stdlib.h>
#include <string.h>
#include <assert.h>

Array * ArrayCreate(){
    Array *arr = malloc(sizeof(Array));
    arr->length_ = 0;
    arr->capacity_ = 32;
    arr->name_ = malloc(sizeof(Character *) * arr->capacity_);
    arr->age_ = malloc(sizeof(Integer) * arr->capacity_);
    return arr;
}

int ArrayGetLength(Array *arr){
    return arr->length_;
};

void ArrayAdd(Array *arr,Character *name,Integer age){
    if(arr->length_ >= arr->capacity_){
        arr->capacity_ *= 2;
        Character **oldName = arr->name_;
        Integer *oldAge = arr->age_;
        arr->name_ = malloc(sizeof(Character*) * arr->capacity_);
        arr->age_ = malloc(sizeof(Integer) * arr->capacity_);
        memcpy(arr->name_, oldName, arr->length_ * sizeof(char*));
        memcpy(arr->age_, oldAge, arr->length_ * sizeof(int));
        free(oldName);
        free(oldAge);
    }
    arr->name_[arr->length_] = name;
    arr->age_[arr->length_] = age;
    OBJECT_RETAIN(arr->name_[arr->length_]);
    OBJECT_RETAIN(arr->age_);
    arr->length_ ++;
};

char *ArrayGetName(Array *arr,int index){
    assert(index >= 0 && index < arr->length_);
    return arr->name_[index]->value_;
};

int ArrayGetAge(Array *arr,int index){
    assert(index >= 0 && index < arr->length_);
    return arr->age_[index].value_;
};

void ArrayDestory(Array *arr){
    free(arr->name_);
    free(arr->age_);
    free(arr);
    printf("数据销毁\n");
};

void ArrayRemoveAtIndex(Array *arr,int index){
    assert(index >= 0 && index < arr->length_);
    OBJECT_RELEASE(arr->name_[index]);
    OBJECT_RELEASE(arr->age_);
    arr->length_--;
    
    for (int i = index; i < arr->length_; i++) {
        arr->name_[i] = arr->name_[i+1];
        arr->age_[i] = arr->age_[i+1];
    }
};

void ArrayFind(Array *arr,int index){
    printf("第%d个位置是姓名:%s\t年龄:%d\n",index,ArrayGetName(arr,index-1),ArrayGetAge(arr,index-1));
};