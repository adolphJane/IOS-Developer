//
//  Character.h
//  Integer
//
//  Created by 江若铭 on 16/5/7.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#ifndef Character_h
#define Character_h

#include <stdio.h>
#include <stdlib.h>
#include "Object.h"

typedef struct Character_{
    int retainCount_;
    char *value_;
} Character;

Character *CharacterNew(char *value);

char *CharacterGet(Character *c);

#endif /* Character_h */
