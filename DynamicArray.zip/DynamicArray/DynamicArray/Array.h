//
//  Array.h
//  DynamicArray
//
//  Created by 江若铭 on 16/5/5.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#ifndef Array_h
#define Array_h

#include <stdio.h>
#include "Integer.h"
#include "Character.h"
#include "Object.h"

typedef Character *CharacterType;
typedef Integer *IntegerType;

typedef struct Array_{
    int length_;
    int capacity_;
    Character **name_;
    Integer *age_;
} Array;

Array * ArrayCreate();

int ArrayGetLength(Array *arr);

void ArrayAdd(Array *arr,Character *name,Integer age);

char *ArrayGetName(Array *arr,int index);

int ArrayGetAge(Array *arr,int index);

void ArrayDestory(Array *arr);

void ArrayRemoveAtIndex(Array *arr,int index);

void ArrayFind(Array *arr,int index);

#endif /* Array_h */
