//
//  Character.c
//  Integer
//
//  Created by 江若铭 on 16/5/7.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#include "Character.h"

Character *CharacterNew(char *value){
    Character *c = malloc(sizeof(Character));
    OBJECT_RETAIN(c);
    c->value_ = value;
    return c;
}

char *CharacterGet(Character *c){
    return c->value_;
};