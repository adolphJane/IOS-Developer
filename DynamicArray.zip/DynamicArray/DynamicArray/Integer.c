//
//  Integer.c
//  Integer
//
//  Created by 江若铭 on 16/5/7.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#include "Integer.h"

Integer* IntegerNew(int32_t value){
    Integer *ins = malloc(sizeof(Integer));
    OBJECT_RETAIN(ins);
    ins->value_ = value;
    return ins;
}

int32_t IntegerGet(Integer *ins){
    return ins->value_;
};