//
//  Integer.h
//  Integer
//
//  Created by 江若铭 on 16/5/7.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#ifndef Integer_h
#define Integer_h

#include <stdio.h>
#include <stdlib.h>
#include "Object.h"

typedef struct Integer_{
    int retainCount_;
    int32_t value_;
} Integer;

Integer *IntegerNew(int32_t value);

int32_t IntegerGet(Integer *ins);

#endif /* Integer_h */
