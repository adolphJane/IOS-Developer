//
//  ViewController.m
//  ViewAttribute
//
//  Created by 江若铭 on 16/5/15.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import "ViewController.h"
#import "PrintNSLog.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIView *blueView;
@property (weak, nonatomic) IBOutlet UIView *greenView;
@property (weak, nonatomic) IBOutlet UIView *azureView;
@property (weak, nonatomic) IBOutlet UIView *redView;
@property (weak, nonatomic) IBOutlet UIView *whiteView;

@end

@implementation ViewController


- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [PrintNSLog printNSLog:self.blueView theViewName:@"BlueView"];
    [PrintNSLog printNSLog:self.greenView theViewName:@"GreenView"];
    [PrintNSLog printNSLog:self.azureView theViewName:@"AzureView"];
    [PrintNSLog printNSLog:self.redView theViewName:@"RedView"];
    [PrintNSLog printNSLog:self.whiteView theViewName:@"WhiteView"];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
    
}

@end
