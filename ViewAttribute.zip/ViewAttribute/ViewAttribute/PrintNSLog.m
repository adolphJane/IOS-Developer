//
//  PrintNSLog.m
//  ViewAttribute
//
//  Created by 江若铭 on 16/5/15.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import "PrintNSLog.h"

@implementation PrintNSLog

+(void)printNSLog:(UIView*) view theViewName:(NSString*) viewName{
    NSLog(@"%@`s frame,bounds,center is %@,%@ and %@.",viewName,
          NSStringFromCGRect(view.frame),
          NSStringFromCGRect(view.bounds),
          NSStringFromCGPoint(view.center));
}

@end
