//
//  PrintNSLog.h
//  ViewAttribute
//
//  Created by 江若铭 on 16/5/15.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface PrintNSLog : NSObject

+(void)printNSLog:(UIView*) view theViewName:(NSString*) viewName;
@end
