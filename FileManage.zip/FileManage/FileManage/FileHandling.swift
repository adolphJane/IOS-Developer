//
//  FileHandling.swift
//  FileManage
//
//  Created by 江若铭 on 16/8/1.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit



class FileHandling {
    var fileManager:NSFileManager!
    var myDir:String!
    var filePath:String!
    var anotherMyDir:String!
    var currentDir:String!
    
    struct TextInfo {
        var dic = NSDictionary()
        var array = NSArray()
        var string = String()
    }
    
    init(){
        fileManager = NSFileManager.defaultManager()
        myDir = NSHomeDirectory() + "/Documents/MyFolder"
        anotherMyDir = NSHomeDirectory() + "/Documents/MyFolder/Copy"
        createDic("Copy")
        currentDir = myDir
        
    }
    
    //创建文件夹
    func createDic(path:String) -> Bool{
        currentDir = "\(myDir)/\(path)"
        var isExists = false
        do{
            if isFileExist(path) {
                isExists = true
            }else{
                try fileManager.createDirectoryAtPath(currentDir, withIntermediateDirectories: true, attributes: nil)
                print(fileManager.currentDirectoryPath)
            }
            
        }catch{
            
        }
        return isExists
    }
    //创建文件
    func createTextFile(fileName:String ,textInfoStr:String) -> Bool{
        let txtPath = "\(currentDir)/\(fileName)"
        var isExists = false
        do{
            if isFileExist(fileName) {
                isExists = true
            }else{
                try textInfoStr.writeToFile(txtPath, atomically: true, encoding: NSUTF8StringEncoding)
            }
        }catch{
        }
        return isExists
    }
    
    func createArrayFile(fileName:String ,textInfoArray:NSArray) -> Bool{
        let txtPath = "\(currentDir)/\(fileName)"
        var isExists = false
        if isFileExist("\(fileName)") {
            isExists = true
        }else{
            textInfoArray.writeToFile(txtPath, atomically: true)
        }
        return isExists
    }
    
    func createDicFile(fileName:String ,textInfoDic:NSDictionary) -> Bool{
        let txtPath = "\(currentDir)/\(fileName)"
        var isExists = false
        if isFileExist("\(fileName)") {
            isExists = true
        }else{
            textInfoDic.writeToFile(txtPath, atomically: true)
        }
        return isExists
    }
    //读取文件
    func readTextFile(fileName:String) -> String{
        var content = String()
        do{
            let txtPath = "\(currentDir)/\(fileName)"
            if isFileExist(fileName) {
                try content = NSString(contentsOfFile: txtPath, encoding: NSUTF8StringEncoding) as String
            }else{
                print("文本文件不存在")
            }
            
        }catch{
            
        }
        return content
    }
    
    func readArrayFile(fileName:String) -> NSArray{
        var content = NSArray()
        
            let txtPath = "\(currentDir)/\(fileName)"
            if isFileExist(fileName) {
                content = NSArray(contentsOfFile: txtPath)!
            }else{
                print("文本文件不存在")
            }
        return content
    }
    
    func readDicFile(fileName:String) -> NSDictionary{
        var content = NSDictionary()
        
        let txtPath = "\(currentDir)/\(fileName)"
        if isFileExist(fileName) {
            content = NSDictionary(contentsOfFile: txtPath)!
        }else{
            print("文本文件不存在")
        }
        return content
    }
    //文件是否存在
    func isFileExist(filePath:String) -> Bool {
        let path = "\(myDir)/\(filePath)"
        let isExists = fileManager.fileExistsAtPath(path)
        return isExists
    }
    //移动文件
    func moveFile(filePath:String,fileName:String) -> Bool{
        let dir = "\(anotherMyDir)/\(fileName)"
        let dirOriginal = "\(myDir)/\(filePath)"
        var isSuccess = false
        
        do{
            if isFileExist(filePath) {
                try fileManager.moveItemAtPath(dirOriginal, toPath: dir)
                isSuccess = true
            }
        }catch{
        }
        return isSuccess
    }
    //复制文件
    func copyFile(filePath:String ,fileName:String) -> Bool{
        let dir = "\(anotherMyDir)/\(fileName)"
        let dirOriginal = "\(myDir)/\(filePath)"
        print(dirOriginal)
        print(dir)
        var isSuccess = false
        
        do{
            if isFileExist(filePath) {
                try fileManager.copyItemAtPath(dirOriginal, toPath: dir)
                isSuccess = true
            }
        }catch{
            
        }
        return isSuccess
    }
    //获取所有文件
    func obtainAllFile(dirPath:String) -> NSArray{
        let dir = "\(myDir)/\(dirPath)"
        var fileArray:NSArray!
        
        if isFileExist(dirPath) {
            fileArray = fileManager.subpathsAtPath(dir)
        }else{
            print("文件路径不存在")
        }
        return fileArray
    }
    //删除文件
    func removeFile(filePath:String) -> Bool{
        let path = "\(myDir)/\(filePath)"
        var isSuccess = false
        
        do{
            if isFileExist(filePath) {
                try fileManager.removeItemAtPath(path)
                isSuccess = true
            }
            
        }catch{
            
        }
        return isSuccess
    }
    //删除所有文件
    func removeAllFileAtPath(dirPath:String) -> Bool{
        let path = "\(myDir)/\(dirPath)"
        var isSuccess = false
        do{
            if isFileExist(dirPath) {
                try fileManager.removeItemAtPath(path)
                try fileManager.createDirectoryAtPath(path, withIntermediateDirectories: true, attributes: nil)
                isSuccess = true
            }
        }catch{
            
        }
        return isSuccess
    }
    //计算文件大小
    func computeFileSize(filePath:String) -> Int32{
        
        var attributes:NSDictionary!
        var fileSize = Int32()
        do{
            if isFileExist(filePath){
                let path = "\(myDir)/\(filePath)"
                try attributes = fileManager.attributesOfItemAtPath(path)
                fileSize = (attributes.objectForKey(NSFileSize)?.intValue)!
            }else{
                print("文件不存在")
            }
            
        }catch{
            
        }
        return fileSize
    }
    
    func computeAllFileSize(dicPath:String) -> Int32{
        let path = "\(myDir)/\(dicPath)"
        let childDic = fileManager.subpathsAtPath(path)
        var file = ""
        var  s = 0
        var fileSize = Int32()
        
        
        while s < childDic?.count {
            file = childDic![s]
            var fileAbsolutePath = "\(dicPath)/\(file)"
            fileAbsolutePath.removeAtIndex(fileAbsolutePath.startIndex)
            fileSize += computeFileSize(fileAbsolutePath)
            s += 1
        }
        return fileSize
    }

}
