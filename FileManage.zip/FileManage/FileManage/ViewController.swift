//
//  ViewController.swift
//  FileManage
//
//  Created by 江若铭 on 16/7/31.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit


class ViewController: UIViewController {
    
    var fileHandle:FileHandling!
    
    @IBOutlet weak var secondFileName: UITextField!

    @IBOutlet weak var textFileName: UITextField!
    override func viewDidLoad() {
        super.viewDidLoad()
        
        fileHandle = FileHandling()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    //创建文件夹
    @IBAction func createDirAction(sender: AnyObject) {
        let result = fileHandle.createDic(textFileName.text!)
        if result{
            print("文件夹已存在")
        }else{
            print("成功创建文件夹")
        }
    }
    //创建文件（因为字典和数组都写入plist文件，所以注释一个）
    @IBAction func createFileAction(sender: AnyObject) {
        let str = "This is test 1!"
        let arry = NSArray(array: [1,2,3,4,5])
        let dic = NSDictionary(dictionary: ["name":"zhangsan","age":17])
        var result = Bool()
        
        let path = textFileName.text
        let suffix = getSuffix(path!)
        if suffix == "txt" {
            result = fileHandle.createTextFile(path!, textInfoStr:str)
        }else if suffix == "plist"{
//            result = fileHandle.createArrayFile(path!, textInfoArray: arry)
            result = fileHandle.createDicFile(path!, textInfoDic: dic)
        }
        
        if result {
            print("文件已存在")
        }else{
            print("成功创建文件")
        }
        
    }
    //读取文件
    @IBAction func readFileAction(sender: AnyObject) {
        let path = textFileName.text
        let suffix = getSuffix(path!)
        if suffix == "txt" {
            let result = fileHandle.readTextFile(path!)
            print(result)
        }else if suffix == "plist"{
//            let result = fileHandle.readArrayFile(path!)
            let result = fileHandle.readDicFile(path!)
            print(result)
        }
    }
    //获取所有文件
    @IBAction func obtainAllFileAction(sender: AnyObject) {
        let result = fileHandle.obtainAllFile(textFileName.text!)
        print(result)
    }
    //复制文件
    @IBAction func copyFileAction(sender: AnyObject) {
        let result = fileHandle.copyFile(textFileName.text!, fileName: secondFileName.text!)
        if result {
            print("文件复制成功")
        }else{
            print("文件复制失败")
        }
    }
    //移动文件
    @IBAction func moveFileAction(sender: AnyObject) {
        let result = fileHandle.moveFile(textFileName.text!, fileName: secondFileName.text!)
        if result {
            print("文件移动成功")
        }else{
            print("文件移动失败")
        }
    }
    //计算文件大小
    @IBAction func computeFileSizeAction(sender: AnyObject) {
        let result = fileHandle.computeFileSize(textFileName.text!)
        print("\(textFileName.text)的大小为\(result)字节")
    }
    //文件是否存在
    @IBAction func isExistsFileAction(sender: AnyObject) {
        let result = fileHandle.isFileExist(textFileName.text!)
        if result {
            print("文件存在")
        }else{
            print("文件不存在")
        }
    }
    //删除文件
    @IBAction func removeFileAction(sender: AnyObject) {
        let result = fileHandle.removeFile(textFileName.text!)
        if result {
            print("文件删除成功")
        }else{
            print("文件删除失败")
        }
    }
    //删除所有文件
    @IBAction func removeAllFilesAction(sender: AnyObject) {
        let result = fileHandle.removeAllFileAtPath(textFileName.text!)
        if result {
            print("文件删除成功")
        }else{
            print("文件删除失败")
        }
    }
    
    @IBAction func computeAllFileSizeAction(sender: AnyObject) {
        let result = fileHandle.computeAllFileSize(textFileName.text!)
        print("\(textFileName.text)目录的所有文件大小为\(result)")
    }
    
    func getSuffix(path:String) -> String {
        let range = Range<String.Index>(start: (path.rangeOfString(".")?.endIndex)!, end: (path.endIndex))
        let suffix = path.substringWithRange(range)
        return suffix
    }
    
}

