//
//  Object.c
//  Integer
//
//  Created by 江若铭 on 16/5/7.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#include "Object.h"
#include <stdlib.h>

void ObjectRetain(Object *obj){
    obj->retainCount_++;
};

void ObjectRelease(Object *obj){
    obj->retainCount_--;
    
    if (obj->retainCount_ <= 0) {
        free(obj);
    }
};

int ObjectRetainCount(Object *obj){
    return obj->retainCount_;
};