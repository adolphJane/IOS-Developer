//
//  Student.h
//  HashMap
//
//  Created by 江若铭 on 16/5/8.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#ifndef Student_h
#define Student_h

#include <stdio.h>
#include "Object.h"

typedef struct Student_{
    int retainCount_;
    int age;
    char *name;
} Student;

Student *CreateStudent(int age, char *name);
#endif /* Student_h */
