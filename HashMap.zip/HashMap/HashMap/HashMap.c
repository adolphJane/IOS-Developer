//
//  HashMap.c
//  HashMap
//
//  Created by 江若铭 on 16/5/5.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#include "HashMap.h"
#include "Object.h"
#include <stdlib.h>
#include <string.h>

int GetIndexByKey(HashMap *map,KEY key){
    int index = -1;
    for (int i = 0; i < map->length_; i++) {
        if(strcmp(map->key_[i], key) == 0){
            index = i;
            break;
        }
    }
    return index;
}

HashMap *MapCreate(){
    HashMap *map = malloc(sizeof(HashMap));
    map->length_ = 0;
    map->capacity_ = 5;
    map->values_ = malloc(sizeof(AnyPoint) * 5);
    map->key_ = malloc(sizeof(KEY) * 5);
    
    return map;
};

void MapPutKey(HashMap *map,KEY key,AnyPoint value){
    if(map->length_ >= map->capacity_){
        AnyPoint *old = map->values_;
        KEY *oldKeys = map->key_;
        map->capacity_ = map->capacity_*2;
        map->values_ = malloc(sizeof(AnyPoint) * map->capacity_);
        memcpy(map->values_, old, (sizeof(AnyPoint)) * map->length_);
        free(old);
        
        map->key_ = malloc(sizeof(KEY) * map->capacity_);
        memcpy(map->key_, oldKeys, (sizeof(KEY)) * map->length_);
        free(oldKeys);
    }
    
    int index = GetIndexByKey(map, key);
    if(index == -1){
        map->values_[map->length_] = value;
        map->key_[map->length_] = key;
        map->length_++;
        OBJECT_RETAIN(value);
    }else{
        map->values_[index] = value;
        map->key_[index] = key;
        OBJECT_RETAIN(value);
    }
};

void MapRemoveKey(HashMap *map,KEY key){
    int index = GetIndexByKey(map, key);
    if(index != -1){
        OBJECT_RELEASE(map->values_[index]);
        map->length_--;
        for (int i = index; i < map->length_; i++) {
            map->values_[i] = map->values_[i+1];
            map->key_[i] = map->key_[i+1];
        }
    }
};

AnyPoint MapGetKey(HashMap *map,KEY key){
    for (int i = 0; i < map->length_; i++) {
        if(strcmp(map->key_[i], key) == 0){
            return map->values_[i];
        }
    }
    return NULL;
};

int MapGetLength(HashMap *map){
    return map->length_;
};

void MapDestroy(HashMap *map){
    free(map->values_);
    free(map->key_);
    free(map);
};