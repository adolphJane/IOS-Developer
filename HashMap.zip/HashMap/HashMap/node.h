//
//  node.h
//  HashMap
//
//  Created by 江若铭 on 16/5/7.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#ifndef node_h
#define node_h

#include <stdio.h>

typedef struct Node_{
    char *value_;
    char *key_;
} Node;

Node *NodeCreate();

#endif /* node_h */
