//
//  HashMap.h
//  HashMap
//
//  Created by 江若铭 on 16/5/5.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#ifndef HashMap_h
#define HashMap_h

#include <stdio.h>
#include "node.h"
#include "Object.h"
#include "Student.h"

typedef Student* AnyPoint;
typedef char* KEY;

typedef struct HashMap_{
    int8_t length_;
    int8_t capacity_;
    KEY *key_;
    AnyPoint *values_;
} HashMap;

HashMap *MapCreate();

void MapPutKey(HashMap *map,KEY key,AnyPoint value);

void MapRemoveKey(HashMap *map,KEY key);

AnyPoint MapGetKey(HashMap *map,KEY key);

void MapDestroy(HashMap *map);

int MapGetLength(HashMap *map);
#endif /* HashMap_h */
