//
//  node.c
//  HashMap
//
//  Created by 江若铭 on 16/5/7.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#include "node.h"
#include <stdlib.h>

Node *NodeCreate(){
    Node *node = malloc(sizeof(Node));
    node->key_ = "";
    node->value_ = "";
    return node;
}