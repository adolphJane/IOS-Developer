//
//  main.c
//  HashMap
//
//  Created by 江若铭 on 16/5/5.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#include <stdio.h>
#include "Object.h"
#include <stdlib.h>
#include "HashMap.h"

void printStudent(AnyPoint stu){
    if(stu != NULL){
        printf("%s\t%d\n",stu->name,stu->age);
    }else{
        printf("Don`t have this.\n");
    }
}

int main(int argc, const char * argv[]) {
    
    
    printf("创建插入\n");
    HashMap *map = MapCreate();
    MapPutKey(map, "num1", CreateStudent(23, "大明"));
    MapPutKey(map, "num2", CreateStudent(12, "小黄"));
    MapPutKey(map, "num3", CreateStudent(24, "小明"));
    MapPutKey(map, "num4", CreateStudent(16, "小红"));
    printStudent( MapGetKey(map, "num1"));
    printStudent( MapGetKey(map, "num2"));
    printStudent( MapGetKey(map, "num3"));
    printStudent( MapGetKey(map, "num4"));
    
    printf("删除\n");
    MapRemoveKey(map, "num2");
    printStudent( MapGetKey(map, "num2"));
    
    printf("插入同一个节点\n");
    MapPutKey(map, "num4", CreateStudent(17, "小L"));
    printStudent( MapGetKey(map, "num4"));
    
    printf("释放内存\n");
    MapDestroy(map);
    return 0;
}
