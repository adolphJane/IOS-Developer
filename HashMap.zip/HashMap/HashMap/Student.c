//
//  Student.c
//  HashMap
//
//  Created by 江若铭 on 16/5/8.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#include "Student.h"
#include <stdlib.h>

Student *CreateStudent(int age, char *name){
    Student *s = malloc(sizeof(Student));
    s->name = malloc(sizeof(char));
    
    s->age = age;
    s->name = name;
    
    OBJECT_RETAIN(s);
    return s;
};