//
//  ViewController.m
//  Calculator
//
//  Created by 江若铭 on 16/5/10.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UITextField *input1;
@property (weak, nonatomic) IBOutlet UITextField *input2;
@property (weak, nonatomic) IBOutlet UIButton *add;
@property (weak, nonatomic) IBOutlet UIButton *sub;
@property (weak, nonatomic) IBOutlet UIButton *mul;
@property (weak, nonatomic) IBOutlet UIButton *div;
@property (weak, nonatomic) IBOutlet UILabel *result;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    [self.add addTarget:self action:@selector(calculate:) forControlEvents:UIControlEventTouchUpInside];
    [self.sub addTarget:self action:@selector(calculate:) forControlEvents:UIControlEventTouchUpInside];
    [self.mul addTarget:self action:@selector(calculate:) forControlEvents:UIControlEventTouchUpInside];
    [self.div addTarget:self action:@selector(calculate:) forControlEvents:UIControlEventTouchUpInside];
}

-(void)calculate:(UIButton*)btn{
    NSString *strInput_1 = self.input1.text;
    NSString *strInput_2 = self.input2.text;
    float fResult = 0.0;
    int8_t flag = 0;
    
    if(![strInput_1 isEqualToString:@""] && ![strInput_2 isEqualToString:@""]){
        if([btn.titleLabel.text isEqualToString:@"加"]){
            fResult = [strInput_1 floatValue] + [strInput_2 floatValue];
        }else if([btn.titleLabel.text isEqualToString:@"减"]){
            fResult = [strInput_1 floatValue] - [strInput_2 floatValue];
        }else if([btn.titleLabel.text isEqualToString:@"乘"]){
            fResult = [strInput_1 floatValue] * [strInput_2 floatValue];
        }else if([btn.titleLabel.text isEqualToString:@"除"]){
            if([strInput_2 floatValue] == 0){
                flag = 1;
            }else{
                fResult = [strInput_1 floatValue] / [strInput_2 floatValue];
            }
        }
    }else{
        flag = 2;
    }
    
    if(flag == 0){
        self.result.text = [NSString stringWithFormat:@"%.02f",fResult];
    }else if(flag == 1){
        self.result.text = @"除数不能为0！";
    }else if(flag == 2){
        self.result.text = @"输入的数字不能为空！";
    }
    
}


- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
