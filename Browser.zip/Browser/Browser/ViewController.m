//
//  ViewController.m
//  Browser
//
//  Created by 江若铭 on 16/5/18.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import "ViewController.h"
#import "SingerModel.h"

@interface ViewController ()

@property(nonatomic,strong)NSMutableArray *arrayAll;

@property(nonatomic,strong)UILabel *titleLabel;

@property(nonatomic,strong)UIImageView *imgView;
//上一张按钮
@property(nonatomic,strong)UIButton *btnBack;
//下一张按钮
@property(nonatomic,strong)UIButton *btnNext;
//定位
@property(nonatomic,assign)int iIndex;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    [self show];
    
}

-(void)show{
    [self titleLabel];
    [self imgView];
    [self btnBack];
    [self btnNext];
}

#pragma mark 上一页
-(void)back{
    if(self.iIndex > 0){
        self.iIndex--;
        self.btnNext.backgroundColor = [UIColor blueColor];
        if(self.iIndex == 0){
            self.btnBack.backgroundColor = [UIColor blackColor];
        }
    }
    
    SingerModle *model = self.arrayAll[self.iIndex];
    
    NSString *strTitle = [NSString stringWithFormat:@"%@ %d/%lu",model.name,self.iIndex + 1,(unsigned long)self.arrayAll.count];
    self.titleLabel.text = strTitle;
    
    self.imgView.image = [UIImage imageNamed:model.pic];
}

#pragma mark 下一页
-(void)next{
    
    if(self.iIndex < self.arrayAll.count - 1){
        self.iIndex++;
        self.btnBack.backgroundColor = [UIColor blueColor];
        if(self.iIndex == self.arrayAll.count - 1){
            self.btnNext.backgroundColor = [UIColor blackColor];
        }
    }
    
    SingerModle *model = self.arrayAll[self.iIndex];
    
    NSString *strTitle = [NSString stringWithFormat:@"%@ %d/%lu",model.name,self.iIndex + 1,(unsigned long)self.arrayAll.count];
    self.titleLabel.text = strTitle;
    
    self.imgView.image = [UIImage imageNamed:model.pic];
}

#pragma mark 懒加载
-(UIButton*)btnNext{
    UIButton *btnNext = [[UIButton alloc]initWithFrame:CGRectMake(180, 400, 80, 40)];
    
    btnNext.backgroundColor = [UIColor grayColor];
    
    [btnNext setTitle:@"下一张" forState:UIControlStateNormal];
    [btnNext setBackgroundColor:[UIColor blueColor]];
    
    [btnNext addTarget:self action:@selector(next) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:btnNext];
    
    self.btnNext = btnNext;
    
    return btnNext;
}

-(UIButton*)btnBack{
    UIButton *btnBack = [[UIButton alloc]initWithFrame:CGRectMake(60, 400, 80, 40)];
    
    btnBack.backgroundColor = [UIColor grayColor];
    
    [btnBack setTitle:@"上一张" forState:UIControlStateNormal];
    
    [btnBack setBackgroundColor:[UIColor blackColor]];
    
    [btnBack addTarget:self action:@selector(back) forControlEvents:UIControlEventTouchUpInside];
    
    [self.view addSubview:btnBack];
    
    self.btnBack = btnBack;
    
    return btnBack;
}

-(UIImageView*)imgView{
    SingerModle *model = self.arrayAll[0];
    
    UIImageView *imgView = [[UIImageView alloc]initWithFrame:CGRectMake(60, 120, 200, 200)];
    imgView.backgroundColor = [UIColor redColor];
    
    imgView.center = self.view.center;
    
    [self.view addSubview:imgView];
    
    self.imgView = imgView;
    
    imgView.image = [UIImage imageNamed:model.pic];
    
    return imgView;
}

-(UILabel*)titleLabel{
    SingerModle *model = self.arrayAll[0];
    
    UILabel *titleLabel = [[UILabel alloc]initWithFrame:CGRectMake(60, 100, 200, 30)];
    titleLabel.backgroundColor = [UIColor redColor];
    
    [self.view addSubview:titleLabel];
    
    self.titleLabel = titleLabel;
    
    NSString *strTitle = [NSString stringWithFormat:@"%@ %d/%lu",model.name,1,(unsigned long)self.arrayAll.count];
    
    titleLabel.text = strTitle;
    
    titleLabel.textAlignment = NSTextAlignmentCenter;
    
    return titleLabel;
}

-(NSMutableArray*)arrayAll{
    if(!_arrayAll){
        _arrayAll = [NSMutableArray array];
        
        NSString *strPath = [[NSBundle mainBundle]pathForResource:@"picList" ofType:@"plist"];
        
        NSLog(@"%@",strPath);

        
        NSArray *array = [NSArray arrayWithContentsOfFile:strPath];
        
        
        for(NSDictionary *dict in array){
            SingerModle *model = [SingerModle singerModelWithDict:dict];
            
            [_arrayAll addObject:model];
        }
    }
    return _arrayAll;
}

@end
