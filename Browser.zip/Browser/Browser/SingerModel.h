//
//  SingerModle.h
//  Browser
//
//  Created by 江若铭 on 16/5/18.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SingerModle : NSObject

@property(nonatomic,copy)NSString *name;

@property(nonatomic,copy)NSString *pic;

-(instancetype)initWithDict:(NSDictionary *)dic;

+(instancetype)singerModelWithDict:(NSDictionary *)dic;

@end
