//
//  SingerModle.m
//  Browser
//
//  Created by 江若铭 on 16/5/18.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import "SingerModel.h"

@implementation SingerModle

-(instancetype)initWithDict:(NSDictionary *)dic{
    self = [super init];
    
    if(self){
        [self setValuesForKeysWithDictionary:dic];
    }
    
    return self;
}

+(instancetype)singerModelWithDict:(NSDictionary *)dic{
    return [[SingerModle alloc]initWithDict:dic];
}

@end
