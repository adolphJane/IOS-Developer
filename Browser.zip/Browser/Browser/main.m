//
//  main.m
//  Browser
//
//  Created by 江若铭 on 16/5/18.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

int main(int argc, char * argv[]) {
    @autoreleasepool {
        return UIApplicationMain(argc, argv, nil, NSStringFromClass([AppDelegate class]));
    }
}
