//
//  ViewController.m
//  CodeAutoLayout
//
//  Created by 江若铭 on 16/5/21.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()

@property(nonatomic,retain) UIView *viewRed;

@property(nonatomic,retain) UIView *viewGreen;

@property(nonatomic,retain) UIView *viewBlue;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    
    [self addView];
    [self setConstraints];
    
}

-(void)addView{
    UIView *viewRed = [[UIView alloc]init];
    viewRed.backgroundColor = [UIColor redColor];
    self.viewRed = viewRed;
    [self.view addSubview:viewRed];
    
    UIView *viewGreen = [[UIView alloc]init];
    viewGreen.backgroundColor = [UIColor greenColor];
    self.viewGreen = viewGreen;
    [self.view addSubview:viewGreen];
    
    UIView *viewBlue = [[UIView alloc]init];
    viewBlue.backgroundColor = [UIColor blueColor];
    self.viewBlue = viewBlue;
    [viewRed addSubview:viewBlue];
}

-(void)setConstraints{
    self.view.translatesAutoresizingMaskIntoConstraints = NO;
    self.viewRed.translatesAutoresizingMaskIntoConstraints = NO;
    self.viewGreen.translatesAutoresizingMaskIntoConstraints = NO;
    self.viewBlue.translatesAutoresizingMaskIntoConstraints = NO;
    
    NSArray *arrParentH = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-20-[viewRed]-20-[viewGreen(==viewRed)]-20-|" options:NSLayoutFormatAlignAllTop|NSLayoutFormatAlignAllBottom metrics:nil views:@{@"viewRed":self.viewRed,@"viewGreen":self.viewGreen}];
    
    [self.view addConstraints:arrParentH];
    
    NSArray *arrParentV = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-40-[viewRed(200)]" options:0 metrics:nil views:@{@"viewRed":self.viewRed}];
    [self.view addConstraints:arrParentV];
    
    NSArray *arrH = [NSLayoutConstraint constraintsWithVisualFormat:@"H:|-0-[viewBlue]" options:0 metrics:nil views:@{@"viewRed":self.viewRed,@"viewBlue":self.viewBlue}];
    [self.viewRed addConstraints:arrH];
    
    NSArray *arrV = [NSLayoutConstraint constraintsWithVisualFormat:@"V:|-0-[viewBlue]" options:0 metrics:nil views:@{@"viewRed":self.viewRed,@"viewBlue":self.viewBlue}];
    [self.viewRed addConstraints:arrV];
    
    NSLayoutConstraint *h=[NSLayoutConstraint constraintWithItem:self.viewBlue attribute:NSLayoutAttributeHeight relatedBy:NSLayoutRelationEqual toItem:self.viewRed attribute:NSLayoutAttributeHeight multiplier:0.5 constant:0];
    NSLayoutConstraint *v=[NSLayoutConstraint constraintWithItem:self.viewBlue attribute:NSLayoutAttributeWidth relatedBy:NSLayoutRelationEqual toItem:self.viewRed attribute:NSLayoutAttributeWidth multiplier:0.5 constant:0];
    [self.viewRed addConstraint:h];
    [self.viewRed addConstraint:v];
}

@end
