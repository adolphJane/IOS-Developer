//
//  main.swift
//  Swift_Nine
//
//  Created by 江若铭 on 16/4/23.
//  Copyright © 2016年 Adolph. All rights reserved.
//

import Foundation

for i in 1...9{
    for j in 1...i{
        print("  \(j)*\(i)=\(i*j)\t",terminator:"")
    }
    print("")
}