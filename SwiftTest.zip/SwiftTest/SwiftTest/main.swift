//
//  main.swift
//  SwiftTest
//
//  Created by 江若铭 on 16/4/23.
//  Copyright © 2016年 Adolph. All rights reserved.
//

import Foundation

//结构体
struct Student {
    var name:String
    var mathScore:Double
    var englishScore:Double
    
    func averageValue() -> Double {
        return  (self.mathScore + self.englishScore)/2
    }
    init(name: String ,mathScore: Double ,englishScore: Double){
        self.name = name
        self.mathScore = mathScore
        self.englishScore = englishScore
    }
}
//构造10个学生
var student_01 = Student(name:"alibaba",mathScore: 34.0,
                 englishScore: 99.0)
var student_02 = Student(name:"kjslued",mathScore: 56.0,
                 englishScore: 88.0)
var student_03 = Student(name:"slfudef",mathScore: 79.0,
                 englishScore: 58.0)
var student_04 = Student(name:"sadifed",mathScore: 37.0,
                 englishScore: 27.0)
var student_05 = Student(name:"ofbkljl",mathScore: 34.0,
                 englishScore: 27.0)
var student_06 = Student(name:"slkadjf",mathScore: 84.0,
                 englishScore: 73.0)
var student_07 = Student(name:"xcljvej",mathScore: 38.0,
                 englishScore: 48.0)
var student_08 = Student(name:"dlkklje",mathScore: 12.0,
                 englishScore: 47.0)
var student_09 = Student(name:"woeurwe",mathScore: 28.0,
                 englishScore: 89.0)
var student_10 = Student(name:"piudsps",mathScore: 48.0,
                 englishScore: 58.0)

func printResult(student:Student) {
    
}

//建立保存学生的数组
var arrStudent = [Student]()

arrStudent.append(student_01)
arrStudent.append(student_02)
arrStudent.append(student_03)
arrStudent.append(student_04)
arrStudent.append(student_05)
arrStudent.append(student_06)
arrStudent.append(student_07)
arrStudent.append(student_08)
arrStudent.append(student_09)
arrStudent.append(student_10)

//冒泡排序，按平均分对学生进行排序
for i in 0..<arrStudent.count{
    for j in i..<arrStudent.count{
        if arrStudent[i].averageValue() > arrStudent[j].averageValue(){
            var temp = arrStudent[i]
            arrStudent[i] = arrStudent[j]
            arrStudent[j] = temp
        }
    }
}

//输出结果
for student in arrStudent{
    print("\(student.name)的平均分是：\(student.averageValue()) 数学：\(student.mathScore) 英语：\(student.englishScore)")
}

