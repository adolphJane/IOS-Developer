//
//  ContentViewController.swift
//  NavigationController
//
//  Created by 江若铭 on 16/5/20.
//  Copyright © 2016年 Adolph. All rights reserved.
//

import UIKit

class ContentViewController: UIViewController {

    private var content:String!
    
    @IBOutlet weak var conentTV: UITextView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        conentTV.text = content
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func setContent(str:String){
        self.content = str
    }
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
