//
//  main.swift
//  Split
//
//  Created by 江若铭 on 16/4/27.
//  Copyright © 2016年 Adolph. All rights reserved.
//

import Foundation

let str:NSString = "Hello&jikexueyuan&Hello"

print(str.split("&"))
print(str.split("jikexueyuan"))


