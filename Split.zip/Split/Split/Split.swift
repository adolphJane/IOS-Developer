//
//  Split.swift
//  Split
//
//  Created by 江若铭 on 16/4/27.
//  Copyright © 2016年 Adolph. All rights reserved.
//

import Foundation

extension NSString{
    func split(str:NSString) -> [String] {
        
        var strResult = [String]()
        var result:String = String()
        var i:Int = 0
        while i<self.length {
            if(self.length - i > str.length){
                if self.substringWithRange(NSMakeRange(i,str.length)) != str{
                    let temp = String(self.substringWithRange(NSMakeRange(i, 1)))
                    result.append(Character(temp))
                    i += 1
                }else{
                    
                    i += str.length
                    strResult.append(result)
                    result = ""
                }
            }else{
                let temp = String(self.substringWithRange(NSMakeRange(i, 1)))
                result.append(Character(temp))
                i += 1
            }
        }
            
        strResult.append(result)
        result = ""
        return strResult
    }
}