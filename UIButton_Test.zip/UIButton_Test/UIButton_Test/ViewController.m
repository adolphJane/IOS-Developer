//
//  ViewController.m
//  UIButton_Test
//
//  Created by 江若铭 on 16/5/15.
//  Copyright © 2016年 Adolph. All rights reserved.
//

#import "ViewController.h"

@interface ViewController ()
@property (weak, nonatomic) IBOutlet UIButton *button;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view, typically from a nib.
    [self setImageButton];
}

-(void)setImageButton{
    UIButton *btn_image = [[UIButton alloc]init];
    btn_image.frame = CGRectMake(20.0, 20.0, 300, 150.0);
    [btn_image setTitle:@"ImageButton" forState:UIControlStateNormal];
    [btn_image setImage:[UIImage imageNamed:@"1.png"] forState:UIControlStateNormal];
    [btn_image setImage:[UIImage imageNamed:@"2.png"] forState:UIControlStateHighlighted];
    [btn_image setTitleEdgeInsets:UIEdgeInsetsMake(0, -150, 0,150)];
    [btn_image setImageEdgeInsets:UIEdgeInsetsMake(0, 120, 0,-120)];
    
    [self.view addSubview:btn_image];
}

-(IBAction)btn_changed:(UIButton*)sender{
    switch (sender.tag) {
        case 10:
            self.button.selected = YES;
            self.button.enabled = YES;
            break;
        case 20:
            self.button.selected = NO;
            self.button.enabled = NO;
            break;
        case 30:
            self.button.selected = NO;
            self.button.enabled = YES;
            break;
        default:
            break;
    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

@end
