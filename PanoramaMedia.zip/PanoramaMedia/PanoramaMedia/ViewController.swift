//
//  ViewController.swift
//  PanoramaMedia
//
//  Created by 江若铭 on 16/8/5.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {
    var cmm:CMMotionManager!
    var screenWidth:CGFloat!
    var screenHeight:CGFloat!
    var imageViewCenter:UIImageView!
    var imageViewLeft:UIImageView!
    var imageViewRight:UIImageView!
    var size:CGSize!
    var imageWidth:CGFloat!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        cmm = CMMotionManager()
        screenWidth = UIScreen.mainScreen().bounds.width
        screenHeight = UIScreen.mainScreen().bounds.height
        
        self.initImageView()
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func viewWillDisappear(animated: Bool) {
        self.stopGyro()
    }
    
    override func viewWillAppear(animated: Bool) {
        self.startGyro()
    }
    
    //初始化imageView
    func initImageView() {
        let image = UIImage(named: "pic.png")
        size = image?.size
        imageWidth = screenHeight * size.width / size.height
        
        imageViewCenter = UIImageView(frame: CGRectMake((screenWidth / 2) - (imageWidth / 2), 0, imageWidth, screenHeight))
        imageViewCenter.contentMode = UIViewContentMode.ScaleAspectFit
        imageViewCenter.image = image
        
        imageViewLeft = UIImageView(frame: CGRectMake((screenWidth / 2) - (imageWidth / 2) - imageWidth, 0, imageWidth, screenHeight))
        imageViewLeft.contentMode = .ScaleAspectFit
        imageViewLeft.image = image
        
        imageViewRight = UIImageView(frame: CGRectMake((screenWidth / 2) + (imageWidth / 2), 0, imageWidth, screenHeight))
        imageViewRight.contentMode = .ScaleAspectFit
        imageViewRight.image = image
        
        self.view.addSubview(imageViewCenter)
        self.view.addSubview(imageViewLeft)
        self.view.addSubview(imageViewRight)
    }
    
    func initImageViewFrameRight() {
        self.imageViewCenter.frame = CGRectMake(0, 0, imageWidth, screenHeight)
        self.imageViewLeft.frame = CGRectMake(-imageWidth, 0, imageWidth, screenHeight)
        self.imageViewRight.frame = CGRectMake(imageWidth, 0, imageWidth, screenHeight)
    }
    func initImageViewFrameLeft() {
        self.imageViewCenter.frame = CGRectMake(screenWidth - imageWidth, 0, imageWidth, screenHeight)
        self.imageViewLeft.frame = CGRectMake(screenWidth - 2 * imageWidth, 0, imageWidth, screenHeight)
        self.imageViewRight.frame = CGRectMake(screenWidth, 0, imageWidth, screenHeight)
    }
    
    //启动陀螺仪
    func startGyro() {
        let q = NSOperationQueue.mainQueue()
        
        cmm.gyroUpdateInterval = 1 / 60
        if cmm.gyroAvailable {
            cmm.startGyroUpdatesToQueue(q, withHandler: {
                (gyroData,CMError) -> Void in
                self.movePicture(gyroData!)
            })
        }
    }
    
    //停止陀螺仪
    func stopGyro() {
        if cmm.gyroActive {
            cmm.stopGyroUpdates()
        }
    }
    
    //移动图片
    func movePicture(motion:CMGyroData) {
        let x = motion.rotationRate.x
        
        self.moveAction(x, imageView: self.imageViewCenter)
        self.moveAction(x, imageView: self.imageViewLeft)
        self.moveAction(x, imageView: self.imageViewRight)
        print(self.imageViewCenter.frame.origin.x)
        if Int(self.imageViewLeft.frame.origin.x) >= Int(screenWidth - imageWidth){
            self.initImageViewFrameLeft()
        }else if Int(self.imageViewRight.frame.origin.x) <= 0{
            self.initImageViewFrameRight()
        }
    }
    
    func moveAction(x:Double,imageView:UIImageView) {
        var frame = imageView.frame
        frame.origin.x += CGFloat(NSString(format: "%.2f",(x / (2 * M_PI))).doubleValue * Double(self.imageWidth) / 60.0)
        print("first:\(NSString(format: "%.5f",(x / (2 * M_PI))).doubleValue * Double(self.imageWidth))")
        print(CGFloat(NSString(format: "%.5f",(x / (2 * M_PI))).doubleValue * Double(self.imageWidth) / 60.0))
        imageView.frame = frame
    }

}

