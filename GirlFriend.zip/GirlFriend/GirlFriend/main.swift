//
//  main.swift
//  GirlFriend
//
//  Created by 江若铭 on 16/4/27.
//  Copyright © 2016年 Adolph. All rights reserved.
//

import Foundation

var girl:GirlFriend

for _ in 0..<1000{
    girl = GirlFriend()
    print("name:\(girl.name)\tage:\(girl.age)")
}