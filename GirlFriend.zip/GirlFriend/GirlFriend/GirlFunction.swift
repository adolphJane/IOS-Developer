//
//  GirlFunction.swift
//  GirlFriend
//
//  Created by 江若铭 on 16/4/27.
//  Copyright © 2016年 Adolph. All rights reserved.
//

import Foundation

protocol GirlFunction {
    
    func haveAppointment()
}