//
//  GirlName.swift
//  GirlFriend
//
//  Created by 江若铭 on 16/4/27.
//  Copyright © 2016年 Adolph. All rights reserved.
//

import Foundation


func random(min:UInt32,max:UInt32)->UInt32{
    return  arc4random_uniform(max-min)+min
}

extension String{
    func chooseName() -> String {
        let min:UInt32=97,max:UInt32=123
        var string=""
        for _ in 0..<random(3,max:6){
            string.append(UnicodeScalar(random(min,max:max)))
        }
        return string
    }
}

extension Int{
    func chooseAge() -> Int {
        return Int(random(16,max:25))
    }
}