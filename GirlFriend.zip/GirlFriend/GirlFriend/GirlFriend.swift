//
//  GirlFriend.swift
//  GirlFriend
//
//  Created by 江若铭 on 16/4/27.
//  Copyright © 2016年 Adolph. All rights reserved.
//

import Foundation

public class GirlFriend:GirlFunction{
    private var _name:String
    private var _age:Int
    let s:String = ""
    let i:Int = 0
    
    init(){
        _name = s.chooseName()
        _age = i.chooseAge()
    }
    
    public var name:String{
        get{
            return _name
        }
    }
    
    public var age:Int{
        get{
            return _age
        }
    }
    
    func haveAppointment() {
        
    }
    
}