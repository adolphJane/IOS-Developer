//
//  ViewController.swift
//  ABall
//
//  Created by 江若铭 on 16/8/6.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit
import CoreMotion

class ViewController: UIViewController {

    var ball:Ball!
    var cmm:CMMotionManager!
    var q:NSOperationQueue!
    var speedX:UIAccelerationValue = 0
    var speedY:UIAccelerationValue = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        ball = Ball(frame: CGRectMake(5, 20, 10, 10))
        ball.backgroundColor = UIColor.whiteColor()
        self.view.addSubview(ball)
        
        cmm = CMMotionManager()
        
    }
    
    override func viewWillAppear(animated: Bool) {
        self.startAccelerate()
    }
    
    override func viewWillDisappear(animated: Bool) {
        self.stopAccelerate()
    }
    //开启加速器
    func startAccelerate() {
        cmm.accelerometerUpdateInterval = 1 / 60
        q = NSOperationQueue.currentQueue()
        if cmm.accelerometerAvailable {
            cmm.startAccelerometerUpdatesToQueue(q, withHandler: {
                (accelerateData,NSError) in
                self.moveBall(accelerateData!)
            })
        }
    }
    //停止加速器
    func stopAccelerate() {
        if cmm.accelerometerActive {
            cmm.stopAccelerometerUpdates()
        }
    }
    //小球移动
    func moveBall(accelerateData:CMAccelerometerData) {
        self.speedX += accelerateData.acceleration.x
        self.speedY +=  accelerateData.acceleration.y
        var posX=self.ball.center.x + CGFloat(self.speedX)
        var posY=self.ball.center.y - CGFloat(self.speedY)
        //碰到边框后的反弹处理
        if posX<0 {
            posX=0;
            self.speedX *= -0.4
            
        }else if posX > self.view.bounds.size.width {
            posX=self.view.bounds.size.width
            self.speedX *= -0.4
        }
        if posY<0 {
            posY=0
            self.speedY *= -0.7
        } else if posY>self.view.bounds.size.height{
            posY=self.view.bounds.size.height
            self.speedY *= -0.7
        }
        self.ball.center=CGPointMake(posX,posY)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}