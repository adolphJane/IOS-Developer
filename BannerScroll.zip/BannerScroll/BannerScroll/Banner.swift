//
//  Banner.swift
//  BannerScroll
//
//  Created by 江若铭 on 16/7/26.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class Banner: UIView,UIScrollViewDelegate {

    private var scroll:UIScrollView!
    private var page:UIPageControl!
    private var timer:NSTimer!
    private let numOfPage = 5
    private var pageWidth:CGFloat! = nil
    private var pageHeight:CGFloat! = nil
    private var pic = [String]()
    private var time:Int = 4
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        pageWidth = frame.width
        pageHeight = frame.height
        
        scroll = UIScrollView.init(frame: CGRectMake(0, 0, pageWidth, pageHeight))
        page = UIPageControl.init(frame: CGRectMake(0, 125, pageWidth, 0))
        
    }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
    
    func scrollViewDidScroll(scrollView: UIScrollView) {
        
    }
    
    func scrollViewDidEndDecelerating(scrollView: UIScrollView) {
        let currentPage:Int = Int(scroll.contentOffset.x / pageWidth)
        
        if scroll.contentOffset.x == 0 {
            self.scroll.contentOffset = CGPointMake(CGFloat(3)*pageWidth, 0)
            page.currentPage = 2
        }else if currentPage == 4{
            self.scroll.contentOffset = CGPointMake(CGFloat(1)*pageWidth, 0)
            page.currentPage = 0
        }else{
            page.currentPage = currentPage - 1
        }

    }
    
    func scrollViewWillBeginDragging(scrollView: UIScrollView) {
        self.removeTimer()
    }
    
    func scrollViewDidEndDragging(scrollView: UIScrollView, willDecelerate decelerate: Bool) {
        self.addTimer()
    }
    
    func changePage() {
        let pageNum = page.currentPage
        scroll.contentOffset = CGPointMake(CGFloat(pageNum) * pageWidth, 0)
    }
    
    func addTimer(){
        self.timer = NSTimer.scheduledTimerWithTimeInterval(NSTimeInterval(time), target: self, selector: #selector(self.nextImage), userInfo: nil, repeats: true)
    }
    
    func removeTimer(){
        self.timer.invalidate()
    }
    
    func setInit(picArray:[String],time:Int) {
        self.pic.append(picArray[2])
        self.pic.append(picArray[0])
        self.pic.append(picArray[1])
        self.pic.append(picArray[2])
        self.pic.append(picArray[0])
        
        self.time = time
        
        for i in 0 ..< self.pic.count{
            //show pic scroll
            let imageVc = UIImageView()
            let imageX = CGFloat(i) * pageWidth
            imageVc.frame = CGRectMake(imageX, 0, pageWidth, pageHeight)
            imageVc.image = UIImage(named:pic[i])
                        self.scroll.addSubview(imageVc)
        }
        
        scroll.contentSize = CGSizeMake((CGFloat(Float(numOfPage)) * pageWidth), pageHeight)
        self.scroll.contentOffset = CGPointMake(CGFloat(1)*pageWidth, 0)
        scroll.pagingEnabled = true
        scroll.scrollEnabled = true
        scroll.showsHorizontalScrollIndicator = false
        scroll.showsVerticalScrollIndicator = false
        scroll.scrollEnabled = true
        scroll.delegate = self

        
        page.numberOfPages = self.pic.count - 2
        page.currentPageIndicatorTintColor = UIColor.redColor()
        page.pageIndicatorTintColor = UIColor.whiteColor()
        page.currentPage = 0
        page.addTarget(self, action: #selector(self.changePage), forControlEvents: UIControlEvents.ValueChanged)
        self.addSubview(scroll)
        self.addSubview(page)
        addTimer()

    }
    
    func nextImage(){
        var pageNum = Int(scroll.contentOffset.x / pageWidth)
        if (pageNum == numOfPage-2){
            pageNum = 1
        }else{
            pageNum = pageNum+1
        }
        print(pageNum)
        self.page.currentPage = pageNum - 1
        UIView.animateWithDuration(0.3) { 
            self.scroll.contentOffset = CGPointMake(CGFloat(pageNum) * self.pageWidth, 0)
        }
        
    }
    
    
    
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    

}
