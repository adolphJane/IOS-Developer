//
//  ViewController.swift
//  BannerScroll
//
//  Created by 江若铭 on 16/7/25.
//  Copyright © 2016年 江若铭. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    let image:[String]! = ["banner1.jpg","banner2.jpg","banner3.jpg"]
    var time:Int!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        let banner = Banner(frame: CGRectMake(0,30,self.view.frame.width,160))
        time = 4
        banner.setInit(image, time: time)
        self.view.addSubview(banner)
    }
    
}

